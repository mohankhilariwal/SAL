# ADR-143 — Use hybrid usage ledger and later provider reconciliation

Status: Accepted for Stage 10C `1.17.0`.

See Section 21 of the Stage 10C narrative for context, decision, consequences, risks, mitigations and review trigger.
